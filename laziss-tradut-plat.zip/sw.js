// Service worker de LAZISS TRADUT
// Change le numéro de version à chaque mise à jour du site pour renouveler le cache.
const VERSION = "v1";
const CACHE = "laziss-tradut-" + VERSION;
const SHELL = [
  "./",
  "./index.html",
  "./manifest.json",
  "./icon-192.png",
  "./icon-512.png",
  "./apple-touch-icon.png",
  "./favicon-32.png"
];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (e) => {
  const req = e.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  // Les traductions (MyMemory) et les polices ne sont jamais interceptées.
  if (url.origin !== self.location.origin) return;

  // Pages : réseau d'abord, cache si hors ligne.
  if (req.mode === "navigate") {
    e.respondWith(
      fetch(req)
        .then((res) => {
          const copy = res.clone();
          caches.open(CACHE).then((c) => c.put("./index.html", copy));
          return res;
        })
        .catch(() => caches.match("./index.html"))
    );
    return;
  }

  // Autres fichiers du site : cache d'abord.
  e.respondWith(caches.match(req).then((hit) => hit || fetch(req)));
});
